# HUGS Cards 1 — Two Books Integration

Repo target:
https://github.com/madartz1/hugs-cards1.git

This zip adds two interactive books to the existing HUGS Cards site.

## New pages

Books library:
- /pages/books.html
- clean route: /books

The Boy Who Hated the Shine:
- /pages/books/the-boy-who-hated-the-shine/index.html
- clean route: /book/the-boy-who-hated-the-shine

Milo’s Nature Friends:
- /pages/books/milos-nature-friends/index.html
- clean route: /book/milos-nature-friends

## New assets

- /assets/books/the-boy-who-hated-the-shine/
- /assets/books/milos-nature-friends/

## Updated files

- /index.html
- /_redirects

## How to upload to GitHub

1. Open the repo:
   https://github.com/madartz1/hugs-cards1
2. Click "Add file" → "Upload files".
3. Drag the contents of this zip into the repo root.
4. Commit directly to the main branch.
5. Netlify should redeploy automatically.

## Important

This zip is designed to add/replace only:
- index.html
- _redirects
- pages/books.html
- pages/the-boy-who-hated-the-shine.html
- pages/milos-nature-friends.html
- pages/books/...
- assets/books/...

It does not remove your Send A Hug, Gallery, FAQ, card assets, or Netlify functions.
